from django.views.generic import ListView
from .models import Post
from django.shortcuts import render

class HomePageView(ListView):
    model = Post
    template_name = 'main.html'

def single(request, id=None):
    return render(request, "partial/single.html")
