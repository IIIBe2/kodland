from django.db import models

from ckeditor.fields import RichTextField

class Post(models.Model):
    title = models.CharField('Название', max_length=50)
    task = models.TextField('Описание')
    header_image = models.ImageField(null=True, blank=True, upload_to="images/")


    published_date = models.DateTimeField(
        blank=True, null=True)


    def __str__(self):
        return self.title

