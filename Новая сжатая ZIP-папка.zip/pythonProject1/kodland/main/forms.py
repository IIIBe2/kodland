from .models import Task
from django import forms
from django.forms import ModelForm, TextInput, Textarea, RadioSelect


class TaskForm(ModelForm):
    class Meta:
        model = Task
        fields = ["title", "task", "header_image"]
        widgets = {
            "title": TextInput(attrs={
                'class': 'form-control-css-title',
                'placeholder': 'Введите название статьи'
            }),
            "task": Textarea(attrs={
                'class': 'form-control-css-tasks',
                'placeholder': ''
            }),

        }
