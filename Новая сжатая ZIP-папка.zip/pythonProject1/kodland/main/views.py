from django.shortcuts import render, redirect
from .forms import *
from django.views.generic import UpdateView
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import HttpResponse
from django.views.generic import ListView, DetailView


def index(request):
    slides = Task.objects.all
    tasks_new = Task.objects.order_by('-id')[:1]
    tasks = Task.objects.order_by('-id')[1:10]
    return render(request, 'main/index.html',
                  {'title': 'Гл страница сайта', 'tasks': tasks, 'tasks_new': tasks_new, 'slides': slides,})

#def HomeView(ListView):
 #   model = Task
  #  template_name = 'main.html'

#class SimpleView(DetailView):
 #   model = Task
  #  template_name = 'simple.html'

class BlogListView(ListView): # новое
    model = Task
    template_name = 'main.html'

class BlogDetailView(DetailView): # новое
    model = Task
    template_name = 'simple_detail.html'

def letter(request):
    error = ''
    if request.method == 'POST':
        form = TaskForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
        else:
            error = 'Статья введена неверно'

    form = TaskForm()
    context = {
        'form': form,
        'error': error
    }
    return render(request, 'main/letter.html', context)


def task_image_view(request):
    if request.method == 'POST':

        form = TaskForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()

            return redirect('success')

    else:

        form = TaskForm()

    return render(request, 'task_image_view.html', {'form': form})


def success(request):
    return HttpResponse('successfully uploaded')


def display_task_images(request):
    if request.method == 'GET':
        # получение всех объектов отеля.

        Tasks_list = Task.objects.all()

        return render((request, 'display_hotel_images.html',

                       {'Tasks_list_images': Tasks_list}))

def simple(request):
    slides = Task.objects.order_by('-id')
    tasks_new = Task.objects.order_by('-id')[:1]
    tasks = Task.objects.order_by('-id')[1:10]
    context = {
        'task_image': slides
    }
    return render(request, 'main/simple.html',
                  {'title': 'Гл страница сайта', 'tasks': tasks, 'tasks_new': tasks_new, 'context': context})