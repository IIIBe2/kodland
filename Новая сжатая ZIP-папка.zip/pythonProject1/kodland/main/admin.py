from django.contrib import admin
from  .models import Task


admin.site.register(Task)

class AdminBlogPost(admin.ModelAdmin):
    list_display = ['title', 'header_image', 'image_img', 'task', 'created_date']
    readonly_fields = ['image_img',]
    fields = ['title', 'task', 'header_image', 'image_img', 'created_date']