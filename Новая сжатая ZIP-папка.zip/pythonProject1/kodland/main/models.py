from django.db import models
from django.utils import timezone, dateformat
from ckeditor.fields import RichTextField

class Task(models.Model):
    title = models.CharField('Название', max_length=50)
    task = RichTextField(blank=True, null=True)
    header_image = models.ImageField(default= 'no_photo.png', null=True, blank=True, upload_to="images/")
    created_date = dateformat.format(timezone.now(), 'd F Y H:i')
    published_date = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Статья'
        verbose_name_plural = 'Статьи'


    def image_img(self):
        if self.header_image:
            return u'<a href="{0}" target="_blank"><img src="{0}" width="100"/></a>'.format(self.header_image.url)
        else:
            return '(Нет изображения, тут пусто) )'
    image_img.short_description = 'Картинка'
    image_img.allow_tags = True

