from django.urls import path
from . import views
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='home'),
    path('simple_detail/<int:pk>', BlogDetailView.as_view(), name='simple_detail'),
    path('letter', views.letter, name='add_letter'),
    path('', display_task_images, name = 'task_images'),
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
